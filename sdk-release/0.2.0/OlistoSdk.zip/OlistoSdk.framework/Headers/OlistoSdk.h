//
//  OlistoSdk.h
//  OlistoSdk
//
//  Created by Michael Olisto on 8/24/18.
//  Copyright © 2018 Olisto. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for OlistoSdk.
FOUNDATION_EXPORT double OlistoSdkVersionNumber;

//! Project version string for OlistoSdk.
FOUNDATION_EXPORT const unsigned char OlistoSdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OlistoSdk/PublicHeader.h>


